#  Ejercicio 3.1 — Funciones con *args  (8 pts)
# ============================================================
def ingreso_total(*montos):
    total = 0
    for monto in montos:
        total += monto
    return total


def mejor_sala(*salas):
    if not salas:
        return ("N/A", 0)

    mejor = salas[0]
    for sala in salas[1:]:
        if sala[1] > mejor[1]:
            mejor = sala
    return mejor


def reporte_multisala(titulo, *funciones):
    lineas = [f"=== {titulo} ==="]
    total = 0

    for i, funcion in enumerate(funciones, start=1):
        nombre, precio, vendidas, descuento = funcion
        ingreso = precio * vendidas * (1 - descuento / 100)
        total += ingreso
        lineas.append(f"Función {i}: {nombre:<15s} | Q{ingreso:.2f}")

    lineas.append("---")
    lineas.append(f"TOTAL: Q{total:.2f}")
    return "\n".join(lineas)


# --- Pruebas (NO modificar) ---
print("=== Ejercicio 3.1 ===")
print(f"Ingreso total: Q{ingreso_total(1500.0, 2300.0, 800.0, 4100.0)}")
print(f"Ingreso vacío: Q{ingreso_total()}")

print(f"Mejor: {mejor_sala(('IMAX', 340), ('3D', 280), ('Kids', 180), ('Premium', 310))}")
print(f"Mejor vacío: {mejor_sala()}")

print()
print(reporte_multisala("Sala IMAX — Sábado",
                        ("Dune 2PM", 85.0, 150, 0),
                        ("Dune 5PM", 85.0, 200, 10),
                        ("Dune 8PM", 95.0, 180, 5)))


# ============================================================
#  Ejercicio 3.2 — Funciones con **kwargs  (8 pts)
# ============================================================
def ficha_pelicula(titulo, duracion, rating, **extras):
    ancho_interno = 33

    top = "┌" + "─" * ancho_interno + "┐"
    titulo_linea = f"│{titulo.center(ancho_interno)}│"
    sep = "├" + "─" * ancho_interno + "┤"

    lineas = [top, titulo_linea, sep]
    lineas.append(f"│ {'Duración':<9}: {duracion} min{' ' * (ancho_interno - len(f' Duración : {duracion} min'))}│")
    lineas.append(f"│ {'Rating':<9}: ★ {rating}{' ' * (ancho_interno - len(f' Rating   : ★ {rating}'))}│")

    for clave, valor in extras.items():
        etiqueta = clave.capitalize()
        contenido = f" {etiqueta:<9}: {valor}"
        lineas.append(f"│{contenido}{' ' * (ancho_interno - len(contenido))}│")

    bottom = "└" + "─" * ancho_interno + "┘"
    lineas.append(bottom)

    return "\n".join(lineas)


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 3.2 ===")
print(ficha_pelicula("Dune: Parte 3", 175, 8.7,
                     director="Villeneuve", genero="Sci-Fi", año=2026))

print(ficha_pelicula("Inside Out 3", 105, 8.9))


# ============================================================
#  Ejercicio 3.3 — Composición de Funciones  (9 pts)
# ============================================================
def calcular_totales(ventas_por_sala):
    resultados = []
    for nombre_sala in ventas_por_sala:
        ventas = ventas_por_sala[nombre_sala]
        total = ingreso_total(*ventas)
        resultados.append((nombre_sala, total))
    return resultados


def ordenar_salas(lista_tuplas):
    ordenadas = lista_tuplas[:]
    n = len(ordenadas)

    for i in range(n):
        for j in range(0, n - i - 1):
            if ordenadas[j][1] < ordenadas[j + 1][1]:
                ordenadas[j], ordenadas[j + 1] = ordenadas[j + 1], ordenadas[j]

    return ordenadas


def tendencia(valores):
    ascendente = True
    descendente = True

    for i in range(1, len(valores)):
        if valores[i] < valores[i - 1]:
            ascendente = False
        if valores[i] > valores[i - 1]:
            descendente = False

    if ascendente:
        return "ascendente"
    elif descendente:
        return "descendente"
    else:
        return "irregular"


def reporte_semanal(nombre_cine, ventas_por_sala):
    totales = calcular_totales(ventas_por_sala)
    ordenadas = ordenar_salas(totales)
    mejor = mejor_sala(*ordenadas)

    lineas = [f"=== REPORTE SEMANAL: {nombre_cine} ==="]

    for i, (nombre, total) in enumerate(ordenadas, start=1):
        prom = total / 7
        t = tendencia(ventas_por_sala[nombre])
        lineas.append(f"#{i} {nombre:<10s} | Total: {int(total):4d} | Prom: {prom:.2f} | Tendencia: {t}")

    lineas.append("---")
    lineas.append(f"Mejor sala de la semana: {mejor[0]} ({int(mejor[1])} entradas)")
    return "\n".join(lineas)


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 3.3 ===")

ventas = {
    "IMAX":     [120, 135, 140, 155, 200, 310, 280],
    "Sala 3D":  [200, 180, 160, 150, 140, 130, 110],
    "Kids":     [90, 95, 100, 105, 110, 115, 120],
    "Premium":  [100, 80, 95, 105, 170, 300, 250],
}

print(reporte_semanal("CineData Plaza", ventas))
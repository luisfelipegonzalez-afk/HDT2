# ============================================================
#  HDT2 — Parte 5: Integrador  (15 pts)
#  CineData GT 2026 — Sistema de Análisis de Cines
# ============================================================

# ============================================================
peliculas = [
    ("Dune: Parte 3", "Sci-Fi", 8.7, 85.0),
    ("Inside Out 3", "Animación", 8.9, 55.0),
    ("Paddington en Guatemala", "Comedia", 9.1, 50.0),
    ("El Contador 3", "Acción", 7.2, 60.0),
    ("Nosferatu 2", "Terror", 6.8, 65.0),
]


def mostrar_menu():
    print("========================================")
    print("       CINEDATA GT 2026")
    print("========================================")
    print("1. Ver cartelera")
    print("2. Comprar entrada")
    print("3. Ver mis compras")
    print("4. Estadísticas")
    print("5. Salir")
    return input("Elige una opción: ").strip()


def mostrar_cartelera(peliculas):
    print("\n=== CARTELERA ===")
    for i, pelicula in enumerate(peliculas, start=1):
        titulo, genero, rating, precio = pelicula
        print(f"[{i}] {titulo} ({genero}) — ★ {rating} — Q{precio:.2f}")


def comprar_entrada(peliculas, compras):
    print("\n=== COMPRAR ENTRADA ===")

    indice = 0
    while indice < 1 or indice > len(peliculas):
        try:
            indice = int(input(f"Elige película (1-{len(peliculas)}): "))
        except ValueError:
            indice = 0
        if indice < 1 or indice > len(peliculas):
            print("Opción no válida. Intenta de nuevo.")

    cantidad = 0
    while cantidad <= 0:
        try:
            cantidad = int(input("Cantidad de entradas: "))
        except ValueError:
            cantidad = 0
        if cantidad <= 0:
            print("Ingresa una cantidad válida mayor que 0.")

    titulo, genero, rating, precio = peliculas[indice - 1]
    total_bruto = precio * cantidad

    if cantidad > 4:
        descuento = round(total_bruto * 0.10, 2)
        total = round(total_bruto - descuento, 2)
        compras.append([titulo, cantidad, precio, total])
        print("Descuento 10% por volumen (>4 entradas)")
        print(f"✓ Compra: {cantidad}x {titulo} — Q{precio:.2f} c/u — Desc: Q{descuento:.2f} — Total: Q{total:.2f}")
    else:
        total = round(total_bruto, 2)
        compras.append([titulo, cantidad, precio, total])
        print(f"✓ Compra: {cantidad}x {titulo} — Q{precio:.2f} c/u — Total: Q{total:.2f}")


def mostrar_compras(compras):
    print("\n=== MIS COMPRAS ===")
    if not compras:
        print("No hay compras registradas.")
        return

    total_general = 0
    contador = 0

    for compra in compras:
        contador += 1
        titulo, cantidad, precio_unitario, total = compra
        total_general += total
        print(f"#{contador} {titulo:<28s} | {cantidad} entradas | Q{total:.2f}")

    print("---")
    print(f"TOTAL: Q{total_general:.2f}")


def resumen_estadisticas(compras):
    print("\n=== ESTADÍSTICAS ===")
    if not compras:
        print("No hay datos para mostrar.")
        return

    total_gastado = 0
    total_entradas = 0
    compra_mas_cara = compras[0]

    contador = 0
    for compra in compras:
        contador += 1
        titulo, cantidad, precio_unitario, total = compra
        total_gastado += total
        total_entradas += cantidad

        if total > compra_mas_cara[3]:
            compra_mas_cara = compra

    promedio = round(total_gastado / contador, 2)

    print(f"Total gastado       : Q{total_gastado:.2f}")
    print(f"Total entradas      : {total_entradas}")
    print(f"Compra más cara     : {compra_mas_cara[0]} (Q{compra_mas_cara[3]:.2f})")
    print(f"Promedio por compra : Q{promedio:.2f}")


def sistema_taquilla(peliculas):
    compras = []

    while True:
        opcion = mostrar_menu()

        if opcion == "1":
            mostrar_cartelera(peliculas)
        elif opcion == "2":
            comprar_entrada(peliculas, compras)
        elif opcion == "3":
            mostrar_compras(compras)
        elif opcion == "4":
            resumen_estadisticas(compras)
        elif opcion == "5":
            total_gastado = 0
            for compra in compras:
                total_gastado += compra[3]
            print(f"¡Gracias por visitar CineData GT! Total gastado: Q{total_gastado:.2f}")
            break
        else:
            print("Opción no válida. Intenta de nuevo.")
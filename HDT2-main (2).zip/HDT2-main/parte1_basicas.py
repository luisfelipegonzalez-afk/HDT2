# ============================================================
#  HDT2 — Parte 1: Funciones Básicas, Parámetros y Return (20 pts)
#  CineData GT 2026 — Sistema de Análisis de Cines
# ============================================================

# ============================================================
#  Ejercicio 1.1 — Precio con Descuento  (4 pts)
# ============================================================

def precio_con_descuento(precio_base, porcentaje):
    descuento = precio_base * (porcentaje / 100)
    return round(precio_base - descuento, 2)


def precio_con_iva(precio, iva):
    impuesto = precio * (iva / 100)
    return round(precio + impuesto, 2)


# --- Pruebas (NO modificar) ---
print("=== Ejercicio 1.1 ===")
print(f"Q100 - 25% = Q{precio_con_descuento(100.0, 25)}")
print(f"Q85 - 10% = Q{precio_con_descuento(85.0, 10)}")
print(f"Q76.5 + 12% IVA = Q{precio_con_iva(76.5, 12)}")
print(f"Q200 + 12% IVA = Q{precio_con_iva(200.0, 12)}")


# ============================================================
#  Ejercicio 1.2 — Clasificador de Películas  (5 pts)
# ============================================================
def clasificar_duracion(minutos):
    if minutos < 90:
        return "corta"
    elif minutos <= 150:
        return "estándar"
    else:
        return "larga"


def clasificar_rating(rating):
    if rating < 4.0:
        return "mala"
    elif rating <= 6.9:
        return "regular"
    elif rating <= 8.4:
        return "buena"
    else:
        return "excelente"


def es_recomendada(duracion, rating):
    tipo_duracion = clasificar_duracion(duracion)
    tipo_rating = clasificar_rating(rating)

    return (tipo_rating == "buena" or tipo_rating == "excelente") and (
        tipo_duracion == "estándar" or tipo_duracion == "corta"
    )


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 1.2 ===")
peliculas = [
    ("Dune: Parte 3", 175, 8.7),
    ("Inside Out 3", 105, 8.9),
    ("Película Mala", 85, 3.2),
    ("Drama Largo", 200, 7.5),
    ("Comedia OK", 95, 6.0),
]
for titulo, dur, rat in peliculas:
    d = clasificar_duracion(dur)
    r = clasificar_rating(rat)
    rec = "Sí" if es_recomendada(dur, rat) else "No"
    print(f"  {titulo:20s} | {d:10s} | {r:10s} | Recomendada: {rec}")


# ============================================================
#  Ejercicio 1.3 — Retorno Múltiple: Análisis de Fila  (5 pts)
# ============================================================
def analizar_ventas(ventas):
    total = 0
    mejor_dia = 0
    peor_dia = 0

    primer_valor = ventas[0]
    mayor = primer_valor
    menor = primer_valor

    indice = 0
    for venta in ventas:
        total += venta

        if venta > mayor:
            mayor = venta
            mejor_dia = indice

        if venta < menor:
            menor = venta
            peor_dia = indice

        indice += 1

    promedio = round(total / indice, 2)
    return total, promedio, mejor_dia, peor_dia


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 1.3 ===")
semana_imax = [120, 95, 110, 130, 200, 340, 290]
dias = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]

total, prom, mejor, peor = analizar_ventas(semana_imax)
print(f"Total: {total}")
print(f"Promedio: {prom}")
print(f"Mejor día: {dias[mejor]} ({semana_imax[mejor]} entradas)")
print(f"Peor día: {dias[peor]} ({semana_imax[peor]} entradas)")


# ============================================================
#  Ejercicio 1.4 — Formato de Reportes  (6 pts)
# ============================================================
def formato_moneda(cantidad):
    return f"Q{cantidad:,.2f}"


def barra_visual(valor, maximo, ancho=20):
    if maximo == 0:
        proporcion = 0
    else:
        proporcion = valor / maximo

    llenos = int(proporcion * ancho + 0.5)
    if llenos > ancho:
        llenos = ancho
    if llenos < 0:
        llenos = 0

    vacios = ancho - llenos
    porcentaje = round(proporcion * 100)

    return "█" * llenos + "░" * vacios + f" {porcentaje}%"


def linea_reporte(nombre, valor, maximo, ancho=20):
    moneda = formato_moneda(valor)
    barra = barra_visual(valor, maximo, ancho)
    return f"{nombre:<14s} | {moneda:<10s} | {barra}"


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 1.4 ===")
print(f"Moneda: {formato_moneda(29250.0)}")
print(f"Moneda: {formato_moneda(850.5)}")
print(f"Barra:  {barra_visual(75, 100)}")
print(f"Barra:  {barra_visual(340, 400, 10)}")
print()

salas_data = [("Sala IMAX", 1285), ("Sala 3D", 953), ("Sala Kids", 675), ("Sala Premium", 1100)]
maximo = 1285
for nombre, valor in salas_data:
    print(linea_reporte(nombre, valor, maximo))
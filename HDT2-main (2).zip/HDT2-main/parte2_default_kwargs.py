# ============================================================
##  Ejercicio 2.1 — Calculadora de Ingresos Flexible  (7 pts)
# ============================================================
def calcular_ingreso(precio_base, vendidas, descuento=0.0, iva=12.0, propina_pct=0.0):
    ingreso_bruto = precio_base * vendidas
    monto_descuento = ingreso_bruto * (descuento / 100)
    subtotal = ingreso_bruto - monto_descuento
    monto_iva = subtotal * (iva / 100)
    monto_propina = subtotal * (propina_pct / 100)
    total = subtotal + monto_iva + monto_propina

    return (
        round(ingreso_bruto, 2),
        round(monto_descuento, 2),
        round(subtotal, 2),
        round(monto_iva, 2),
        round(monto_propina, 2),
        round(total, 2),
    )


# --- Pruebas (NO modificar) ---
print("=== Ejercicio 2.1 ===")

# Caso 1: solo precio y vendidas (usa defaults)
r1 = calcular_ingreso(85.0, 100)
print(f"Caso 1 — Bruto: Q{r1[0]} | Desc: Q{r1[1]} | Sub: Q{r1[2]} | IVA: Q{r1[3]} | Prop: Q{r1[4]} | Total: Q{r1[5]}")

# Caso 2: con descuento usando keyword arg
r2 = calcular_ingreso(85.0, 100, descuento=15.0)
print(f"Caso 2 — Bruto: Q{r2[0]} | Desc: Q{r2[1]} | Sub: Q{r2[2]} | IVA: Q{r2[3]} | Prop: Q{r2[4]} | Total: Q{r2[5]}")

# Caso 3: sin IVA (evento exento) con propina
r3 = calcular_ingreso(50.0, 200, iva=0.0, propina_pct=10.0)
print(f"Caso 3 — Bruto: Q{r3[0]} | Desc: Q{r3[1]} | Sub: Q{r3[2]} | IVA: Q{r3[3]} | Prop: Q{r3[4]} | Total: Q{r3[5]}")


# ============================================================
#  Ejercicio 2.2 — Generador de Credenciales  (6 pts)
# ============================================================
def generar_credencial(nombre_completo, zona="general", numero=1, prefijo="CD26"):
    partes = nombre_completo.split()
    inicial_primero = partes[0][0].upper()
    inicial_ultimo = partes[-1][0].upper()
    zona3 = zona[:3].upper()
    numero_formato = str(numero).zfill(4)

    return f"{prefijo}-{zona3}-{inicial_primero}{inicial_ultimo}{numero_formato}"


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 2.2 ===")
print(generar_credencial("Carlos Mendoza", zona="vip", numero=47))
print(generar_credencial("Ana García", numero=5))
print(generar_credencial("José Roberto López", zona="preferencia", numero=312))
print(generar_credencial("María Luisa Fernández Torres", zona="imax", numero=88, prefijo="FE26"))


# ============================================================
#  Ejercicio 2.3 — Constructor de Reportes Configurable  (7 pts)
# ============================================================
def construir_reporte(titulo, datos, moneda="Q", mostrar_promedio=True,
                      mostrar_ranking=False, ancho_nombre=20):
    linea_titulo = titulo.center(40, "=")
    lineas = [linea_titulo]

    total = 0
    cantidad = 0

    for i, (nombre, valor) in enumerate(datos, start=1):
        if mostrar_ranking:
            nombre_mostrar = f"#{i} {nombre}"
        else:
            nombre_mostrar = nombre

        lineas.append(f"{nombre_mostrar:<{ancho_nombre}}{moneda}{valor:,.2f}")
        total += valor
        cantidad += 1

    lineas.append("---")

    if mostrar_promedio:
        promedio = round(total / cantidad, 2) if cantidad > 0 else 0
        lineas.append(f"{'Promedio':<{ancho_nombre}}{moneda}{promedio:,.2f}")

    return "\n".join(lineas)


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 2.3 ===")
ventas = [
    ("Sala IMAX", 29250.0),
    ("Sala 3D", 15800.0),
    ("Sala Kids", 8900.0),
    ("Sala Premium", 21500.0),
]

# Reporte simple
print(construir_reporte("VENTAS DEL DÍA", ventas))

# Reporte con ranking, sin promedio, en dólares
print(construir_reporte("TOP SALAS", ventas, moneda="$",
   mostrar_promedio=False, mostrar_ranking=True))
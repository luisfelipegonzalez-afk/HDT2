# ============================================================
#  HDT2 — Parte 4: Scope, Diseño Modular y Reutilización (20 pts)
#  CineData GT 2026 — Sistema de Análisis de Cines
# ============================================================

##  Ejercicio 4.1 — Acumuladores con Scope Correcto  (6 pts)
# ============================================================
def procesar_ventas(lista_ventas):
    total = 0
    conteo = 0
    positivos = 0

    mejor = lista_ventas[0]
    peor = lista_ventas[0]

    for venta in lista_ventas:
        total += venta
        conteo += 1

        if venta > 0:
            positivos += 1

        if venta > mejor:
            mejor = venta

        if venta < peor:
            peor = venta

    promedio = round(total / conteo, 2)

    return {
        "total": total,
        "conteo": conteo,
        "promedio": promedio,
        "positivos": positivos,
        "mejor": mejor,
        "peor": peor
    }


def comparar_periodos(ventas_actual, ventas_anterior):
    stats_actual = procesar_ventas(ventas_actual)
    stats_anterior = procesar_ventas(ventas_anterior)

    total_actual = stats_actual["total"]
    total_anterior = stats_anterior["total"]
    diferencia = total_actual - total_anterior

    if total_anterior == 0:
        cambio_pct = 0.0
    else:
        cambio_pct = round((diferencia / total_anterior) * 100, 1)

    if diferencia > 0:
        veredicto = "mejora"
    elif diferencia < 0:
        veredicto = "declive"
    else:
        veredicto = "estable"

    return {
        "total_actual": total_actual,
        "total_anterior": total_anterior,
        "diferencia": diferencia,
        "cambio_pct": cambio_pct,
        "veredicto": veredicto
    }


# --- Pruebas (NO modificar) ---
print("=== Ejercicio 4.1 ===")
stats = procesar_ventas([120, 95, 110, 0, 200, 340, 290])
print(f"Stats: {stats}")

comp = comparar_periodos(
    [120, 135, 140, 155, 200, 310, 280],  # esta semana
    [100, 110, 105, 120, 180, 290, 250],  # semana pasada
)
print(f"Actual: {comp['total_actual']} | Anterior: {comp['total_anterior']}")
print(f"Diferencia: {comp['diferencia']} ({comp['cambio_pct']}%) → {comp['veredicto']}")


# ============================================================
#  Ejercicio 4.2 — Funciones como Herramientas Reutilizables  (7 pts)
# ============================================================
def aplicar_a_cada(funcion, lista):
    resultado = []
    for elemento in lista:
        resultado.append(funcion(elemento))
    return resultado


def filtrar(funcion, lista):
    resultado = []
    for elemento in lista:
        if funcion(elemento):
            resultado.append(elemento)
    return resultado


def reducir(funcion, lista, inicial):
    resultado = inicial
    for elemento in lista:
        resultado = funcion(resultado, elemento)
    return resultado


# --- Funciones auxiliares para pruebas (NO modificar) ---
def doble(x):
    return x * 2

def es_mayor_100(x):
    return x > 100

def sumar(a, b):
    return a + b

def mayor(a, b):
    if a > b:
        return a
    return b


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 4.2 ===")
ventas = [120, 95, 340, 80, 200, 55, 180]

dobles = aplicar_a_cada(doble, ventas)
print(f"Dobles: {dobles}")

grandes = filtrar(es_mayor_100, ventas)
print(f"Mayores a 100: {grandes}")

total = reducir(sumar, ventas, 0)
print(f"Total (reducir): {total}")

maximo = reducir(mayor, ventas, 0)
print(f"Máximo (reducir): {maximo}")


# ============================================================
#  Ejercicio 4.3 — Pipeline de Análisis Modular  (7 pts)
# ============================================================
def analisis_completo(datos_salas):
    resumen = []

    for nombre_sala in datos_salas:
        total_sala = reducir(sumar, datos_salas[nombre_sala], 0)
        resumen.append((nombre_sala, total_sala))

    def es_fuerte(tupla_sala):
        return tupla_sala[1] > 1000

    salas_fuertes_tuplas = filtrar(es_fuerte, resumen)
    salas_fuertes = aplicar_a_cada(lambda t: t[0], salas_fuertes_tuplas)

    totales_fuertes = aplicar_a_cada(lambda t: t[1], salas_fuertes_tuplas)
    proyeccion_quincenal = aplicar_a_cada(doble, totales_fuertes)

    gran_total_proyectado = reducir(sumar, proyeccion_quincenal, 0)

    return {
        "resumen": resumen,
        "salas_fuertes": salas_fuertes,
        "proyeccion_quincenal": proyeccion_quincenal,
        "gran_total_proyectado": gran_total_proyectado
    }


# --- Pruebas (NO modificar) ---
print("\n=== Ejercicio 4.3 ===")
datos = {
    "IMAX":     [120, 135, 140, 155, 200, 310, 280],
    "Sala 3D":  [85, 70, 90, 88, 150, 260, 210],
    "Kids":     [60, 55, 65, 70, 95, 180, 150],
    "Premium":  [100, 80, 95, 105, 170, 300, 250],
}

resultado = analisis_completo(datos)
print("Resumen:")
for nombre, total in resultado["resumen"]:
    print(f"  {nombre:10s}: {total}")
print(f"Salas fuertes (>1000): {resultado['salas_fuertes']}")
print(f"Proyección quincenal: {resultado['proyeccion_quincenal']}")
print(f"Gran total proyectado: {resultado['gran_total_proyectado']}")